function attachEvents() {
  const loadBooksBtn = document.getElementById("loadBooks");
  loadBooksBtn.addEventListener("click", loadAllBooksHandler);
  const booksContainer = document.querySelector("table > tbody");
  //const tableRows = Array.from(document.getElementsByTagName("tr"));
  //let tableCols = Object.values(tableRows);
  const submitBtn = document.querySelector("#form button");

  const editBtns = Array.from(
    document.querySelectorAll("tr > td > button:nth-child(2n+1)")
  );

  const BASE_URL = "http://localhost:3030/jsonstore/collections/books/";

  submitBtn.addEventListener("click", addBookHandler);

  function loadAllBooksHandler() {
    fetch(BASE_URL)
      .then((res) => res.json())
      .then((data) => {
        booksContainer.innerHTML = "";
        for (const bookId in data) {
          const { author, title } = data[bookId];

          const tr = document.createElement("tr");
          booksContainer.appendChild(tr);

          const titleCol = document.createElement("td");
          const authorCol = document.createElement("td");
          const buttonCol = document.createElement("td");
          authorCol.textContent = author;
          titleCol.textContent = title;
          tr.appendChild(titleCol);
          tr.appendChild(authorCol);
          tr.appendChild(buttonCol);
          let button1 = document.createElement("button");
          let button2 = document.createElement("button");
          buttonCol.appendChild(button1);
          buttonCol.appendChild(button2);
          button1.textContent = "Edit";
          button2.textContent = "Delete";

          const editBtns = Array.from(
            document.querySelectorAll("tr > td > button:nth-child(2n+1)")
          );

          const delBtns = Array.from(
            document.querySelectorAll("tr > td > button:nth-child(2n)")
          );

          editBtns.forEach((editBtn) => {
            editBtn.addEventListener("click", editHandler);
          });

          delBtns.forEach((delBtn) => {
            delBtn.addEventListener("click", deleteHandler);
          });
          //editHandler();
          //buttonCol.appendChild(button2);
        }

        //console.log(data);
        //console.log(tableCols[0].textContent);
        //console.log(tableCols[1].textContent);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function addBookHandler() {
    const inputs = Array.from(document.querySelectorAll("#form input"));
    const title = inputs[0].value;
    const author = inputs[1].value;
    const httpHeaders = {
      method: "Post",
      body: JSON.stringify({
        author: author,
        title: title,
      }),
    };
    fetch(`${BASE_URL}`, httpHeaders)
      .then((res) => res.json())
      .then(() => {
        editBtns.forEach((editBtn) => {
          editBtn.addEventListener("click", editHandler);
        });

        if (submitBtn.textContent === "Save") {
          const httpHeaders = {
            method: "P",
            body: JSON.stringify({
              author: author,
              title: title,
            }),
          };
        }
        loadAllBooksHandler();
        inputs[0].value = "";
        inputs[1].value = "";
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function editHandler() {
    console.log("clicked");
    const headerText = document.querySelector("#form > h3");
    headerText.textContent = "Edit FORM";
    let currentRow = this.parentElement.parentElement;
    let currentTitle = currentRow.children[0].textContent;
    let currentAuthor = currentRow.children[1].textContent;

    let inputs = document.querySelectorAll("#form > input");
    console.log(inputs);
    inputs[0].value = currentTitle;
    inputs[1].value = currentAuthor;

    submitBtn.textContent = "Save";
  }

  function deleteHandler() {
    let currentRow = this.parentElement.parentElement;
    console.log(currentRow);
    const title = currentRow.children[0].textContent;
    const author = currentRow.children[1].textContent;
    document.removeChild(currentRow.children[0]);
    document.removeChild(currentRow.children[1]);
    document.removeChild(currentRow.children[2]);
    console.log(title);
    console.log(author);

    fetch(BASE_URL)
      .then((res) => res.json())
      .then((data) => {
        for (const id in data) {
          let { tit, aut } = data;
          if (title === tit && author === aut) {
            console.log(title === tit);
            const httpHeaders = {
              method: "DELETE",
            };
            fetch(BASE_URL + id)
              .then(loadAllBooksHandler)
              .catch((err) => {
                console.log(err);
              });
          }
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }
}

attachEvents();
