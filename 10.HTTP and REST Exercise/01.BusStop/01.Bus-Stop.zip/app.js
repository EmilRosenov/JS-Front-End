function getInfo() {
  const stopIdField = document.getElementById("stopId");
  const stopId = stopIdField.value;
  const stopNameField = document.getElementById("stopName");
  const resultField = document.getElementById("buses");

  resultField.innerHTML = "";
  const BASE_URL = "http://localhost:3030/jsonstore/bus/businfo/";
  fetch(`${BASE_URL}${stopId}`)
    .then((res) => res.json())
    .then((busInfo) => {
      console.log(busInfo);
      const { buses, name } = busInfo;
      stopNameField.textContent = name;

      for (const id in buses) {
        let busId = id;
        let time = buses[id];
        let li = document.createElement("li");
        li.textContent = `Bus ${busId} arrives in ${time} minutes`;
        resultField.appendChild(li);
      }
    })
    .catch((err) => {
      stopNameField.textContent = "Error";
      console.error(err);
    });
}
