function attachEvents() {
  const phoneBookContainer = document.getElementById("phonebook");
  const loadBtn = document.getElementById("btnLoad");
  const BASE_URL = "http://localhost:3030/jsonstore/phonebook/";

  loadBtn.addEventListener("click", loadHandler);

  const createBtn = document.getElementById("btnCreate");
  const personInput = document.getElementById("person");
  const phoneInput = document.getElementById("phone");

  createBtn.addEventListener("click", createHandler);

  async function loadHandler() {
    try {
      const phoneBookREs = await fetch(BASE_URL);
      let phoneBookData = await phoneBookREs.json();
      phoneBookData = Object.values(phoneBookData);

      // if i dont delete phonebook container--> it will load not only the new created contact but will add also the same existinfg contacts;
      phoneBookContainer.innerHTML = "";
      for (const { person, phone, _id } of phoneBookData) {
        const li = document.createElement("li");
        const button = document.createElement("button");
        button.textContent = "Delete";
        button.id = _id;
        button.addEventListener("click", deleteHandler);
        li.innerHTML = `${person}: ${phone}`;
        li.appendChild(button);
        phoneBookContainer.appendChild(li);
      }
    } catch (error) {
      console.log(error);
    }
  }

  function createHandler() {
    const person = personInput.value;
    const phone = phoneInput.value;

    //here I played along a little bit
    // console.log(`${person}:${phone}`);
    // const h2 = Array.from(document.getElementsByTagName("h2"))[0];
    // console.log(`${h2.textContent}`);
    // h2.textContent = "";

    const httpHeaders = {
      method: "POST",
      body: JSON.stringify({ person, phone }),
    };

    fetch(`${BASE_URL}`, httpHeaders)
      .then((res) => res.json)
      .then(() => {
        loadHandler();
        personInput.value = "";
        phoneInput.value = "";
      })
      .catch((err) => {
        console.log(err);
      });
  }

  async function deleteHandler() {
    const id = this.id;
    console.log(id);

    const httpHeaders = {
      method: "DELETE",
    };

    try {
      await fetch(`${BASE_URL}${id}`, httpHeaders)
        .then((res) => res.json)
        .then(loadHandler);
    } catch (error) {
      console.log(error);
    }
  }
}
attachEvents();
