function solve() {
  const info = document.querySelector(".info");
  const [departBtn, arriveBtn] = document.querySelectorAll("input");
  const BASE_URL = "http://localhost:3030/jsonstore/bus/schedule/";
  let [nextId, location] = ["depot", null];
  const test = {
    name: "Depot",
    next: "0361",
  };

  async function depart() {
    const response = await fetch(`${BASE_URL}${nextId}`);
    const data = await response.json();
    location = data.name;
    nextId = data.next;
    info.textContent = `Next stop ${location}`;
    departBtn.disabled = true;
    arriveBtn.disabled = false;
  }

  async function arrive() {
    info.textContent = `Arriving at ${location}`;
    departBtn.disabled = false;
    arriveBtn.disabled = true;
  }

  return {
    depart,
    arrive,
  };
}

let result = solve();
